#ifndef __CMDD_H__
#define __CMDD_H__

#include "contiki.h"

PROCESS_NAME(cmdd_process);

#endif /* __CMDD_H__ */
